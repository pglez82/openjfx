function getArticles() {
  var articles = [  {"name": "first article","id": "first_article","category": "articles","url": "articles/article_firstarticle.html"},
  {"name": "faq","id": "faq","category": "articles","url": "articles/article_faq.html"},
  {"name": "second article","id": "second_article","category": "articles","url": "articles/article_secondarticle.html"},
  {"name": "mediawiki article","id": "mediawiki_article","category": "articles","url": "articles/article_test.html"},
  {"name": "Containing...","id": "Containing...","category": "fulltext","title": "","titleID": "","url": "fullTextSearch.html"}]
  return articles;
}