function getFullTextContent() {
  var fullText = [  {"name": "Home","id": "_index_","meta": "The index for the tutorial wiki","url": "index.html"},
  {"name": "First article","id": "first_article","meta": "The content of the first article","url": "articles/article_firstarticle.html"},
  {"name": "FAQ","id": "faq","meta": "Frequently Asked Questions","url": "articles/article_faq.html"},
  {"name": "Second article","id": "second_article","meta": "The content of the second article","url": "articles/article_secondarticle.html"},
  {"name": "Mediawiki article","id": "mediawiki_article","meta": "The content of the Mediawiki article","url": "articles/article_test.html"}]
  return fullText;
}