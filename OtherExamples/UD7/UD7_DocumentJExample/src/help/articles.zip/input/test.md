{{name:Mediawiki article}}
  
The content of the Mediawiki article.
  
[[Category:articles]]